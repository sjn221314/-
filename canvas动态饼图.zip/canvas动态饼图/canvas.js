function DrawCircle(canvasId, data_arr, color_arr) {
	this.canvasId = canvasId;
	this.data_arr = data_arr;
	this.color_arr = color_arr;
	this.timer = null;
	this.agl = 0;
	this.startAgl = 0;
	this.endAgl = 0
	this.timer = null;
	this.index = 0
	this.pi = Math.PI * 2;
}
DrawCircle.prototype.init = function () {
	var _canvasId = document.getElementById(this.canvasId);
	var c = _canvasId.getContext("2d");
	this.create(c);
}
DrawCircle.prototype.create = function (c) {
	c.fillStyle = this.color_arr[this.index];
	this.endAgl += this.data_arr[this.index];

	var This = this;
	this.timer = setInterval(function(){
		This.draw(c);
	}, 10);
}
DrawCircle.prototype.draw = function (c) {
	this.agl += 0.01;
	c.beginPath();
	c.moveTo(300, 300);
	c.arc(300, 300, 300, this.startAgl* this.pi, this.agl* this.pi, false);
	c.lineTo(300, 300);
	c.fill();
	if (this.agl >= this.endAgl) {
		this.agl = this.endAgl;
		clearInterval(this.timer);
		this.startAgl = this.agl;
		if (this.index <= this.data_arr.length - 1) {
			this.index++;
			if (this.endAgl >= 1) {
				clearInterval(this.timer);
				return;
			}
			this.create(c);
		}
	}
}